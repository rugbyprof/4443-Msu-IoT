# Reaction Duel Game – Student Build Guide

## Overview
This project is a 2-player reaction game where players race to press a button after a "GO" signal appears on the OLED screen. Too early and you're disqualified!

---

## 🔧 Materials
See the included `reaction_game_full_bom_20250725.csv` for the complete parts list.

## 🛠️ Assembly Instructions
1. **Breadboard or solder the circuit** using the following connections:
   - ESP32 to OLED: I2C (SDA to GPIO21, SCL to GPIO22)
   - Player buttons: GPIO14 (Player 1), GPIO27 (Player 2)
   - Countdown LED: GPIO12
   - Buzzer: GPIO26

2. **Flash the Arduino code** from `reaction_duel_game.ino` to your ESP32 using Arduino IDE.

3. **Test the game** before moving to the PCB version.

4. **Design your enclosure** using Tinkercad, Fusion 360, or OpenSCAD.

## 🧪 Extension Ideas
- Add a 7-segment display to track score.
- Penalize early presses with a “False Start” message.
- Design a 3D-printed case with player name plates.

## 📦 Deliverables
- Working game on a custom PCB
- Final code and enclosure
- A short demo video or live test in lab
