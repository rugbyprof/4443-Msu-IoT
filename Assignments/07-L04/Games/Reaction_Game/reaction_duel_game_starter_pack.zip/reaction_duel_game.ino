#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET    -1
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

// Pins
const int player1Button = 14;  // GPIO14
const int player2Button = 27;  // GPIO27
const int ledPin = 12;         // Countdown LED
const int buzzerPin = 26;

bool gameStarted = false;
unsigned long reactionStart = 0;

void setup() {
  Serial.begin(115200);
  pinMode(player1Button, INPUT_PULLUP);
  pinMode(player2Button, INPUT_PULLUP);
  pinMode(ledPin, OUTPUT);
  pinMode(buzzerPin, OUTPUT);

  display.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);
  display.setTextSize(2);
  display.setCursor(0, 0);
  display.println("Ready?");
  display.display();
  delay(2000);
}

void loop() {
  display.clearDisplay();
  display.setCursor(0, 0);
  display.setTextSize(1);
  display.println("Wait for it...");
  display.display();

  delay(random(3000, 7000));
  digitalWrite(ledPin, HIGH);
  tone(buzzerPin, 1000, 200);
  display.clearDisplay();
  display.setCursor(0, 0);
  display.setTextSize(2);
  display.println("GO!");
  display.display();
  reactionStart = millis();

  while (true) {
    if (digitalRead(player1Button) == LOW) {
      announceWinner(1);
      break;
    }
    if (digitalRead(player2Button) == LOW) {
      announceWinner(2);
      break;
    }
  }
  delay(3000);
  digitalWrite(ledPin, LOW);
}

void announceWinner(int player) {
  display.clearDisplay();
  display.setCursor(0, 0);
  display.setTextSize(2);
  display.print("P");
  display.print(player);
  display.println(" wins!");
  display.display();
  tone(buzzerPin, 2000, 400);
}
