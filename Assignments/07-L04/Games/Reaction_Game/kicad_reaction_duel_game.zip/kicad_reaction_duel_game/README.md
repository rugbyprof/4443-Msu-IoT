# Reaction Duel Game (KiCad Project)

This is a starter KiCad project for an ESP32-based reaction time game. Includes schematic and layout placeholders.